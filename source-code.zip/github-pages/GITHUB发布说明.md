# 发布到GitHub

## 发布后会得到什么

- 一个公开源码仓库：同学可以查看、下载、修改代码。
- 一个GitHub Pages网址：朋友直接用浏览器打开网站，不需要连接同一个Wi-Fi。

GitHub Pages可发布本项目的菜单、评分抽卡、个人评价、TimeShift、记账和基础营养搭配。共享讨论、公开评价、账号和DeepSeek需要单独的服务器，代码保留在源码包中。

## 当前已发布项目

网站：https://doger4725-dotcom.github.io/shi-a-chi-shen-me/

源码：https://github.com/doger4725-dotcom/shi-a-chi-shen-me

当前远程仓库根目录就是网页发布目录，Pages设置为 `main` + `/ (root)`。下面的 `/docs` 设置适用于完整结构化源码上传后的布局。

## 发布设置

1. 创建公开仓库，建议名称 `shi-a-chi-shen-me`。
2. 把此文件夹中的项目文件上传至仓库根目录，不要上传 `.env.local`、`.local`、`node_modules`。
3. 仓库 Settings → Pages → Source 选 Deploy from a branch。
4. Branch 选 `main`，文件夹选 `/docs`，保存。
5. 等待部署成功，复制Pages显示的实际网址。网址必须保留仓库名称这一段。

## 之后怎么更新

修改 `public/` 或服务端源文件。运行 `node scripts/build-pages.mjs`，再将 `docs/` 内的网页文件更新到当前远程仓库根目录，并更新 `source-code.zip`；Pages会自动重新发布。若采用完整结构化仓库布局，则提交源码与 `docs/` 并将发布目录设置为 `/docs`。

`docs/`是公开演示版本；`public/`配合`node server.mjs`运行具有账号与共享讨论的版本。

## 手机验证

用户已确认手机移动网络能打开GitHub Pages并看到98道菜单和TimeShift。新版本增加评分抽卡；之后可用同一网址继续体验。

官方说明：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
