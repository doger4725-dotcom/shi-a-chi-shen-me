# 发布到GitHub

## 发布后会得到什么

- 一个公开源码仓库：同学可以查看、下载、修改代码。
- 一个GitHub Pages网址：朋友直接用浏览器打开网站，不需要连接同一个Wi-Fi。

GitHub Pages可发布本项目的菜单、加权转盘、TimeShift、记账和基础营养搭配。共享讨论、评分、账号和DeepSeek需要单独的服务器，代码保留在本仓库中。

## 发布设置

1. 创建公开仓库，建议名称 `shi-a-chi-shen-me`。
2. 把此文件夹中的项目文件上传至仓库根目录，不要上传 `.env.local`、`.local`、`node_modules`。
3. 仓库 Settings → Pages → Source 选 Deploy from a branch。
4. Branch 选 `main`，文件夹选 `/docs`，保存。
5. 等待部署成功，复制Pages显示的实际网址。网址必须保留仓库名称这一段。

## 之后怎么更新

修改 `public/` 或服务端源文件。运行 `node scripts/build-pages.mjs` 和 `node scripts/check-pages.mjs`，将源码与更新后的 `docs/` 一起提交，Pages会自动重新发布。

`docs/`是公开演示版本；`public/`配合`node server.mjs`运行具有账号与共享讨论的版本。

## 手机验证

部署完成后，用手机移动网络打开Pages实际网址，检查菜单、预算筛选、转盘和TimeShift。桌面响应式预览不能替代这一步。

官方说明：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
