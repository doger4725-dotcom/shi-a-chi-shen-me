import { readdir, readFile, access } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = new URL('../',import.meta.url);
for(const dir of ['public/','lib/','server/']){
  for(const name of await readdir(new URL(dir,root))){
    if(!/\.(js|mjs)$/.test(name))continue;
    const result=spawnSync(process.execPath,['--check',fileURLToPath(new URL(dir+name,root))],{encoding:'utf8'});
    if(result.status!==0)throw Error(name+': '+result.stderr);
  }
}
const html=await readFile(new URL('public/index.html',root),'utf8');
for(const match of html.matchAll(/(?:src|href)="([a-z0-9_-]+\.(?:js|css))"/g))await access(new URL('public/'+match[1],root));
for(const name of await readdir(new URL('public/',root))){
  if(name.endsWith('.png'))continue;
  const text=await readFile(new URL('public/'+name,root),'utf8');
  if(/sk-[A-Za-z0-9_-]{20,}/.test(text))throw Error('公开资源中疑似含密钥：'+name);
  if(/signin-with-chatgpt|使用 ChatGPT 登录/.test(text))throw Error('迁移登录入口未替换：'+name);
}
console.log('公开资源、语法、登录入口与密钥排除检查通过。');
