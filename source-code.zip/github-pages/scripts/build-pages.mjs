import { mkdir,readdir,readFile,writeFile,copyFile } from 'node:fs/promises';
const root=new URL('../',import.meta.url), source=new URL('public/',root), target=new URL('docs/',root);
await mkdir(target,{recursive:true});
for(const name of await readdir(source)){
  if(!/^[a-z0-9_-]+\.(html|js|css|svg|csv)$/.test(name)||name==='auth.js'||name==='auth.css')continue;
  await copyFile(new URL(name,source),new URL(name,target));
}
async function patch(name,before,after){const path=new URL(name,target),text=await readFile(path,'utf8');if(!text.includes(before))throw Error('发布标记缺失：'+name);await writeFile(path,text.replaceAll(before,after));}
await patch('index.html','<link rel="stylesheet" href="auth.css"><script type="module" src="auth.js"></script>','');
await patch('index.html','<button class="auth-button" id="account-button" type="button">登录 / 注册</button>','');
await patch('index.html','<body>','<body><p class="public-preview-note">公开演示 · 真实菜单、加权转盘、TimeShift、记账和基础搭配可用；共享讨论、评分和DeepSeek待接服务器。</p>');
await patch('index.html','攻略、反馈和评分使用本站账号发布并存入服务器数据库。','此公开演示尚未连接共享讨论与评分数据库。');
await patch('app.js','评分加载中','共享评分待接入');
await patch('app.js','  community?.openReview(entry);','  // 静态版先完成记账，共享评价接入服务器后启用。');
await patch('app.js','data-review-meal="${escape(entry.id)}"','disabled title="共享评分待接服务器"');
await patch('app.js',"'给这顿打分 ★'","'共享评分待接入'");
await patch('app.js','攻略、反馈和评分登录后存入共享数据库。','共享讨论、反馈、评分和DeepSeek待接服务器。');
await patch('community.js',"async function api(query='',options={}){","async function api(query='',options={}){ throw new Error('共享讨论、反馈和评分待接服务器。');");
await patch('community.js','<p>可以点击上方刷新按钮再试。</p>','<p>当前可体验选饭、TimeShift、记账和基础营养搭配。</p>');
await patch('nutrition-ui.js',"const response = await fetch('/api/nutrition', { headers: { Accept: 'application/json' } });","const response = {ok:true,status:200,json:async()=>({configured:false,message:'基础搭配可用；DeepSeek待接服务器。'})};");
await writeFile(new URL('.nojekyll',target),'');
const cssPath=new URL('styles.css',target);
await writeFile(cssPath,(await readFile(cssPath,'utf8'))+'\n.public-preview-note{margin:0;padding:10px 16px;background:#fff0cc;color:#563d18;font-size:13px;line-height:1.6;text-align:center}\n');
console.log('GitHub Pages资源已生成到docs，使用相对路径，支持仓库子目录网址。');
