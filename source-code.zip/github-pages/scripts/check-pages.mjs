import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
const root=new URL('../docs/',import.meta.url), names=await readdir(root);
assert(names.includes('index.html'));assert(names.includes('.nojekyll'));
for(const name of names){
  if(name.endsWith('.png'))continue;
  const text=await readFile(new URL(name,root),'utf8');
  assert(!/sk-[a-zA-Z0-9_-]{20,}/.test(text),'疑似密钥：'+name);
  assert(!/\.env\.local|site\.sqlite/.test(name),'私有文件：'+name);
  if(name==='index.html'){
    assert(text.includes('公开演示'));assert(!text.includes('auth.js'));
    for(const ref of text.matchAll(/(?:src|href)="([a-z0-9_-]+\.(?:js|css))"/g))assert(names.includes(ref[1]),'缺少资源：'+ref[1]);
  }
  if(name.endsWith('.js')){
    for(const ref of text.matchAll(/\bfrom\s*['"]\.\/([^'"]+)['"]/g))assert(names.includes(ref[1]),'模块缺失：'+ref[1]);
  }
  if(name==='app.js'){
    assert(!text.includes('  community?.openReview(entry);'),'静态版记账不应打开共享评分');
    assert(text.includes('personalReviews?.open(reviewButton.dataset.reviewMeal)'),'个人评价入口缺失');
    assert(text.includes('personalizeCandidates(decisionSnapshot.current, state.entries)'),'个人评分未参与权重');
  }
}
console.log('GitHub Pages入口、相对资源路径、模块和密钥排除检查通过。');
