import http from 'node:http';
import {readFile,realpath} from 'node:fs/promises';
import {resolve,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=await realpath(fileURLToPath(new URL('../docs/',import.meta.url)));
const prefix='/shi-a-chi-shen-me/',port=4181;
const types={html:'text/html; charset=utf-8',js:'text/javascript; charset=utf-8',css:'text/css; charset=utf-8',svg:'image/svg+xml',csv:'text/csv; charset=utf-8'};
http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Cache-Control','no-store');
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return;}
  try{
    const url=new URL(req.url,'http://127.0.0.1:'+port);
    if(url.pathname==='/'){res.writeHead(302,{Location:prefix});res.end();return;}
    if(!url.pathname.startsWith(prefix))throw Error('missing');
    const name=decodeURIComponent(url.pathname.slice(prefix.length))||'index.html';
    if(!/^[a-z0-9_-]+\.(html|js|css|svg|csv)$/.test(name))throw Error('missing');
    const path=await realpath(resolve(root,name));if(!path.startsWith(root+sep))throw Error('missing');
    const content=await readFile(path);res.writeHead(200,{'Content-Type':types[name.split('.').at(-1)]});res.end(req.method==='HEAD'?undefined:content);
  }catch{res.writeHead(404);res.end('未找到页面');}
}).listen(port,'127.0.0.1',()=>console.log('GitHub子路径预览：http://127.0.0.1:'+port+prefix));
