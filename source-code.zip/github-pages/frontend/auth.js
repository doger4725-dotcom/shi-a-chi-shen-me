const button = document.querySelector('#account-button');
document.body.insertAdjacentHTML('beforeend', `<dialog class="account-dialog" id="account-dialog" aria-labelledby="account-title"><button class="dialog-close" id="account-close" aria-label="关闭账号窗口">×</button><p class="eyebrow">一起分享食堂攻略</p><h2 id="account-title">登录本站账号</h2><div class="segmented" id="account-tabs"><button type="button" data-account-mode="login" class="selected" aria-pressed="true">登录</button><button type="button" data-account-mode="signup" aria-pressed="false">注册</button></div><form id="account-form"><div class="field"><label for="account-username">用户名</label><input id="account-username" name="username" autocomplete="username" minlength="2" maxlength="24" required placeholder="2～24个汉字、字母、数字或下划线"></div><div class="field"><label for="account-password">密码</label><input id="account-password" name="password" type="password" autocomplete="current-password" minlength="8" maxlength="128" required placeholder="至少8个字符"></div><p class="account-note" id="account-signup-note" hidden>注册后可发布攻略、回复和五星评价。</p><button class="button primary" type="submit" id="account-submit">登录</button></form><p class="account-note" id="account-info" hidden></p><button class="button secondary" id="account-logout" hidden type="button">退出登录</button><p class="account-status" id="account-status" role="status"></p></dialog>`);
const $ = selector => document.querySelector(selector);
const dialog = $('#account-dialog');
let mode = 'login', user = null, busy = false, known = false;
function paint() {
  button.textContent = user ? user.username : '登录 / 注册';
  button.setAttribute('aria-label', user ? '管理账号：' + user.username : '登录或注册本站账号');
  $('#account-title').textContent = user ? '我的账号' : mode === 'signup' ? '注册本站账号' : '登录本站账号';
  $('#account-form').hidden = Boolean(user); $('#account-tabs').hidden = Boolean(user);
  $('#account-info').hidden = !user; $('#account-info').textContent = user ? '已登录：' + user.username : '';
  $('#account-logout').hidden = !user; $('#account-submit').textContent = mode === 'signup' ? '注册并登录' : '登录';
  $('#account-password').autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
  $('#account-signup-note').hidden = mode !== 'signup';
  document.querySelectorAll('[data-account-mode]').forEach(item => {const active = item.dataset.accountMode === mode;item.classList.toggle('selected', active);item.setAttribute('aria-pressed', String(active));});
}
async function request(input) {
  const response = await fetch('/api/auth', input ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(input)} : {});
  const data = await response.json();
  if (!response.ok) throw Error(data.error || '账号服务暂时不可用。');
  return data;
}
async function refresh() {
  try {const data = await request();user = data.user;known = true;paint();}
  catch {known = false;button.textContent = '账号连接重试';}
}
function changed() { window.dispatchEvent(new CustomEvent('auth-changed', {detail:{signedIn:Boolean(user)}})); }
function open() {$('#account-status').textContent = '';if(!dialog.open)dialog.showModal();if(!known)refresh();}
button.addEventListener('click', open);
$('#account-close').addEventListener('click', () => dialog.close());
$('#account-tabs').addEventListener('click', event => {const tab = event.target.closest('[data-account-mode]');if(tab&&!busy){mode = tab.dataset.accountMode;$('#account-status').textContent='';paint();}});
document.addEventListener('click', event => {if(event.target.closest('a[href="#login"]')){event.preventDefault();open();}});
$('#account-form').addEventListener('submit', async event => {
  event.preventDefault();if(busy)return;busy=true;$('#account-submit').disabled=true;$('#account-status').textContent='正在处理…';
  try {const data = await request({action:mode,username:$('#account-username').value,password:$('#account-password').value});user=data.user;known=true;$('#account-password').value='';paint();dialog.close();changed();}
  catch(error){$('#account-status').textContent=error.message;}
  finally{busy=false;$('#account-submit').disabled=false;}
});
$('#account-logout').addEventListener('click', async () => {
  if(busy)return;busy=true;$('#account-logout').disabled=true;
  try{await request({action:'logout'});user=null;known=true;$('#account-password').value='';paint();dialog.close();changed();}
  catch(error){$('#account-status').textContent=error.message;}
  finally{busy=false;$('#account-logout').disabled=false;}
});
paint();refresh();
