import http from 'node:http';
import { readFile, mkdir, realpath } from 'node:fs/promises';
import { resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { networkInterfaces } from 'node:os';
import { createAPI } from './server/api.mjs';
import { localStore } from './server/local-store.mjs';

const root = fileURLToPath(new URL('./', import.meta.url));
try { process.loadEnvFile(resolve(root, '.env.local')); } catch(error) { if(error.code!=='ENOENT')throw error; }
await mkdir(resolve(root,'.local'),{recursive:true});
const store = localStore(resolve(root,'.local','site.sqlite'));
const api = createAPI({store});
const host = process.env.HOST || '127.0.0.1';
const port = Number(process.env.PORT || 4180);
const publicOrigin = process.env.PUBLIC_ORIGIN ? new URL(process.env.PUBLIC_ORIGIN).origin : null;
const addresses = Object.values(networkInterfaces()).flat().filter(Boolean).filter(address=>address.family==='IPv4'&&!address.internal).map(address=>address.address);
const allowedHosts = new Set(['localhost', '127.0.0.1', ...addresses, ...(publicOrigin?[new URL(publicOrigin).hostname]:[])]);
const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.csv':'text/csv; charset=utf-8','.png':'image/png'};
const publicRoot = await realpath(resolve(root,'public'));
export const server = http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
  try{
    const incoming = new URL(req.url,`http://${req.headers.host||'localhost'}`);
    if(!allowedHosts.has(incoming.hostname)){res.writeHead(400);res.end('访问地址无效');return;}
    if(incoming.pathname.startsWith('/api/')){
      let body;
      if(!['GET','HEAD'].includes(req.method)){
        const parts=[];let size=0;
        for await(const part of req){size+=part.length;if(size>120000){res.writeHead(413,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify({error:'提交内容过长。'}));return;}parts.push(part);}
        body=Buffer.concat(parts);
      }
      const request = new Request((publicOrigin||incoming.origin)+incoming.pathname+incoming.search,{method:req.method,headers:req.headers,...(body?{body}:{})});
      const reply = await api(request,{ip:req.socket.remoteAddress||'unknown'});
      res.writeHead(reply.status,Object.fromEntries(reply.headers));res.end(Buffer.from(await reply.arrayBuffer()));return;
    }
    if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,{Allow:'GET, HEAD'});res.end();return;}
    const name=incoming.pathname==='/'?'index.html':decodeURIComponent(incoming.pathname.slice(1));
    if(!/^[a-z0-9_-]+\.(html|js|css|svg|csv|png)$/.test(name)){res.writeHead(404);res.end('未找到页面');return;}
    const path=await realpath(resolve(publicRoot,name));
    if(!path.startsWith(publicRoot+sep)){res.writeHead(404);res.end();return;}
    const data=await readFile(path);res.writeHead(200,{'Content-Type':types[name.slice(name.lastIndexOf('.'))]});res.end(req.method==='HEAD'?undefined:data);
  }catch(error){res.writeHead(error.code==='ENOENT'?404:503,{'Content-Type':'text/plain; charset=utf-8'});res.end(error.code==='ENOENT'?'未找到页面':'服务暂时不可用');}
});
server.requestTimeout=30000;server.headersTimeout=15000;
server.on('error',error=>{console.error('启动失败：'+error.message);store.close();process.exitCode=1;});
server.listen(port,host,()=>{console.log(`完整版本：http://127.0.0.1:${port}/`);if(host==='0.0.0.0')addresses.filter(ip=>/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip)).forEach(ip=>console.log(`同网入口：http://${ip}:${port}/`));});
function stop(){server.close(()=>{store.close();process.exit();});server.closeIdleConnections();}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
