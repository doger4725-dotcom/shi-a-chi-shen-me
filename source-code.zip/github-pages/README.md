# 是啊，吃什么

安徽大学龙河校区第三食堂就餐决策项目。先按预算和用餐时间筛选，再按个人评分抽一张饭卡。

## GitHub公开分享

[打开网站](https://doger4725-dotcom.github.io/shi-a-chi-shen-me/) · [GitHub源码](https://github.com/doger4725-dotcom/shi-a-chi-shen-me)

线上仓库根目录保存公开网页，完整结构化项目随 `source-code.zip` 提供。本源码包的 `public/` 是完整版前端，`docs/` 是生成的公开网页。更新方法见[GITHUB发布说明.md](GITHUB发布说明.md)。用户已确认手机移动网络可以访问。

Pages支持菜单、抽卡、个人五星评价、TimeShift、记账和基础营养搭配；共享讨论、公开评价、账号和DeepSeek需要服务器。完整服务端源码在`server/`中，可在本机运行。

## 直接运行

需要 Node.js 22.13 或更高版本。双击“启动完整版.cmd”，电脑浏览器打开 `http://127.0.0.1:4180/`。

本机运行不需要安装第三方依赖。讨论、账号和评价保存在 `.local/site.sqlite`，重启仍保留。餐费记在各自浏览器里。

## 页面功能

- 照片菜单：98道午餐、24项加料；09号窗口有周日11:30排队到取餐8分钟的实测记录。
- TimeShift：比较去程、等待、出餐、用餐和返回的总时间，给出最快、省钱与综合方案。
- 评分抽卡：预算、时间和口味决定基础权重，个人评分调整权重；卡池公布每道菜的实际概率。
- 用餐后在“我的饭钱”评分并写评论；4～5星“出金了”，1～2星“歪了”，3星保持权重。同菜使用最近一次个人评价。
- 本站账号：注册后发布攻略、回复、APP报错、餐饮服务评价和菜品五星评价。
- 同一餐再次评价会修改原记录；可以撤回自己的内容。
- 基础营养搭配可直接使用；DeepSeek需服务器配置密钥。

照片只覆盖午餐，早餐和晚餐待补录；其他窗口的排队时间使用页面标注的估算来源。

## 看懂代码

| 文件 | 负责什么 |
| --- | --- |
| public/canteen-data.js | 窗口、菜名、价格与实测记录 |
| public/model.js | 等待估算、预算和餐费计算 |
| public/decision.js | 总时间约束、方案比较与抽取概率 |
| public/preferences.js / preferences-ui.js | 个人评分倍数与评价表单 |
| public/app.js | 把数据和按钮接到页面上 |
| public/auth.js | 登录和注册窗口 |
| server/api.mjs | 接收页面请求，分派给账号、讨论和AI |
| server/auth.mjs | 密码校验、会话与登录次数限制 |
| server/community.mjs | 攻略、回复、评分与撤回 |
| server/local-store.mjs | 将共享数据写入SQLite文件 |
| lib/nutrition-ai.mjs | 整理菜单、调用DeepSeek、读取回答 |

## DeepSeek配置

将 `.env.example` 复制为 `.env.local`，把密钥保存在 `DEEPSEEK_API_KEY` 的引号内，重启服务。不要把 `.env.local` 放进公开仓库或源码压缩包。

当前导出包没有复制原网站密钥或原讨论数据库。AI接口按用户和IP限次；自动检查使用模拟回答，迁移版尚未进行真实模型调用。

## 分享网站

源码压缩包可以直接发给同学。要让别人点链接打开，需要把网站部署到公网托管；电脑本机地址不属于公网链接。

当前线上仓库以根目录发布；结构化源码也支持将生成的 `docs/` 设为发布目录。不包含密钥或数据库。

若部署到支持Node.js的服务器：运行 `node server.mjs`，配置 `HOST=0.0.0.0`、`PORT` 和HTTPS网站实际地址 `PUBLIC_ORIGIN`。账号与讨论数据所在目录 `.local` 需要持久保存。反向代理应转发浏览器Origin，HTTPS由托管平台提供。

## 检查

`node scripts/check-package.mjs`检查公开资源、语法和密钥排除。已有自动检查位于 `tests/`。抽卡规则和示例见[抽卡与评分说明.md](抽卡与评分说明.md)。

MIT许可适用于本项目代码。第三方依赖遵循各自许可。
