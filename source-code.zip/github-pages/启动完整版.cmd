@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "taskNode=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if exist "%taskNode%" (
  "%taskNode%" "%~dp0server.mjs"
) else (
  node "%~dp0server.mjs"
)
pause
