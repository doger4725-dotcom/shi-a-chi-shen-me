import test from 'node:test';
import assert from 'node:assert/strict';
import { createAPI } from '../server/api.mjs';
import { localStore } from '../server/local-store.mjs';
import { updateValue, readValue } from '../server/data.mjs';

const origin='https://food.example';
function fixture(options={}) {
  const store=localStore(), api=createAPI({store,...options});
  async function call(path='/api/auth',{method='GET',body,cookie,requestOrigin=origin}={}){
    const headers={...(cookie?{cookie}:{}),...(body!==undefined?{'Content-Type':'application/json',Origin:requestOrigin}:{})};
    const response=await api(new Request(origin+path,{method,headers,...(body!==undefined?{body:JSON.stringify(body)}:{})}),{ip:'192.0.2.1'});
    return{status:response.status,data:await response.json(),cookie:response.headers.get('set-cookie')?.split(';')[0],headers:response.headers};
  }
  const signup=async(username='同学甲')=>call('/api/auth',{method:'POST',body:{action:'signup',username,password:'test-pass-123'}});
  return{store,call,signup};
}
test('账号注册、登录、会话与退出；密码不出现在返回值',async t=>{
  const f=fixture();t.after(()=>f.store.close());
  const created=await f.signup();assert.equal(created.status,201);assert.match(created.cookie,/^__Host-csm-session=/);
  assert.match(created.headers.get('set-cookie'),/HttpOnly/);assert.match(created.headers.get('set-cookie'),/Secure/);
  assert.equal(JSON.stringify(created.data).includes('test-pass'),false);
  assert.equal((await f.call('/api/auth',{cookie:created.cookie})).data.user.username,'同学甲');
  assert.equal((await f.call('/api/auth',{method:'POST',body:{action:'login',username:'同学甲',password:'wrong-pass'}})).status,401);
  assert.equal((await f.call('/api/auth',{method:'POST',body:{action:'login',username:'同学甲',password:'test-pass-123'}})).status,200);
  assert.equal((await f.call('/api/auth',{method:'POST',cookie:created.cookie,body:{action:'logout'}})).status,200);
  assert.equal((await f.call('/api/auth',{cookie:created.cookie})).data.signedIn,false);
});
test('跨站提交、空对象格式与未登录发帖被拒绝',async t=>{
  const f=fixture();t.after(()=>f.store.close());
  assert.equal((await f.call('/api/auth',{method:'POST',body:{action:'signup'},requestOrigin:'https://elsewhere.example'})).status,403);
  assert.equal((await f.call('/api/auth',{method:'POST',body:null})).status,400);
  assert.equal((await f.call('/api/auth',{method:'POST',body:[]})).status,400);
  assert.equal((await f.call('/api/community',{method:'POST',body:{kind:'guide'}})).status,401);
});
test('攻略跨账号可读可回复，仅作者能撤回；不泄露账号标识',async t=>{
  const f=fixture();t.after(()=>f.store.close());
  const a=await f.signup(),b=await f.signup('同学乙');
  const created=await f.call('/api/community',{method:'POST',cookie:a.cookie,body:{kind:'guide',title:'第三食堂攻略',body:'十一点半去九号窗口。',alias:'饭友甲'}});
  assert.equal(created.status,201);const id=created.data.post.id;
  const feed=await f.call('/api/community?kind=guide');assert.equal(feed.data.posts[0].mine,false);assert.equal('authorId' in feed.data.posts[0],false);
  assert.equal((await f.call('/api/community',{method:'POST',cookie:b.cookie,body:{kind:'reply',parentId:id,body:'今天我也去这个窗口。'}})).status,201);
  assert.equal((await f.call('/api/community?kind=reply&parentId='+id)).data.posts.length,1);
  assert.equal((await f.call('/api/community',{method:'DELETE',cookie:b.cookie,body:{id}})).status,404);
  assert.equal((await f.call('/api/community',{method:'DELETE',cookie:a.cookie,body:{id}})).status,200);
  assert.equal((await f.call('/api/community?kind=guide')).data.posts.length,0);
  assert.equal((await f.call('/api/community?kind=reply&parentId='+id)).status,404);
});
test('同餐重复评价更新，星级汇总与归属正确',async t=>{
  const f=fixture();t.after(()=>f.store.close());
  const a=await f.signup(),b=await f.signup('同学乙');
  const input={kind:'dish-review',dishId:'campus-09-1',dishName:'无情拌面',mealKey:'meal-1',rating:5,body:'好吃'};
  const post=await f.call('/api/community',{method:'POST',cookie:a.cookie,body:input});assert.equal(post.status,201);
  const updated=await f.call('/api/community',{method:'POST',cookie:a.cookie,body:{...input,rating:3}});assert.equal(updated.data.post.id,post.data.post.id);
  assert.equal((await f.call('/api/community',{method:'POST',cookie:b.cookie,body:input})).status,201);
  const meta=await f.call('/api/community?view=meta',{cookie:a.cookie});assert.equal(meta.data.ratings[0].count,2);assert.equal(meta.data.ratings[0].average,4);assert.equal(meta.data.reviews.length,1);
  const publicFeed=await f.call('/api/community?kind=dish-review');assert.equal(publicFeed.data.posts.some(p=>'mealKey'in p),false);
  assert.equal((await f.call('/api/community',{method:'POST',cookie:a.cookie,body:{...input,rating:6}})).status,400);
});
test('并发写入使用版本号重试，攻略不丢失',async t=>{
  const f=fixture();t.after(()=>f.store.close());const user=await f.signup();
  const responses=await Promise.all(Array.from({length:6},(_,i)=>f.call('/api/community',{method:'POST',cookie:user.cookie,body:{kind:'guide',title:'攻略'+i,body:'这是食堂攻略内容'+i}})));
  assert.deepEqual(responses.map(x=>x.status),[201,201,201,201,201,201]);
  assert.equal((await f.call('/api/community?kind=guide')).data.posts.length,6);
});
test('存储版本冲突重新读取，存储失败不会假报保存成功',async t=>{
  const store=localStore();t.after(()=>store.close());
  await Promise.all(Array.from({length:6},()=>updateValue(store,'count',{n:0},value=>{value.n++;return{result:value.n};})));
  assert.equal((await readValue(store,'count')).n,6);
  const api=createAPI({store:{async getWithMetadata(){throw Error('internal storage detail');}}});
  const response=await api(new Request(origin+'/api/community'));assert.equal(response.status,503);assert.equal((await response.text()).includes('internal storage'),false);
});
test('AI配置缺失有明确状态，配置后使用服务器密钥和调用限额',async t=>{
  const calls=[];const env={};
  const f=fixture({settings:()=>env,fetcher:async(url,options)=>{calls.push({url,options});return Response.json({choices:[{finish_reason:'stop',message:{content:'西红柿鸡蛋拌面：8元。'}}]});}});t.after(()=>f.store.close());
  const user=await f.signup();
  assert.equal((await f.call('/api/nutrition')).status,401);
  assert.equal((await f.call('/api/nutrition',{cookie:user.cookie})).data.configured,false);
  const body={question:'帮我选午餐',menu:[{name:'西红柿鸡蛋拌面',price:8,periods:['lunch']}],budget:40,reserve:6,menuMode:'campus'};
  assert.equal((await f.call('/api/nutrition',{method:'POST',cookie:user.cookie,body})).status,503);
  env.DEEPSEEK_API_KEY='fixture-secret-never-real';
  for(let i=0;i<10;i++)assert.equal((await f.call('/api/nutrition',{method:'POST',cookie:user.cookie,body})).status,200);
  assert.equal((await f.call('/api/nutrition',{method:'POST',cookie:user.cookie,body})).status,429);
  assert.equal(calls.length,10);assert.equal(calls[0].options.headers.Authorization,'Bearer fixture-secret-never-real');
  assert.equal(calls[0].url,'https://api.deepseek.com/chat/completions');
});
test('超长提交与非法星级不写入，用户数据不会进入公开账号响应',async t=>{
  const f=fixture();t.after(()=>f.store.close());const user=await f.signup();
  assert.equal((await f.call('/api/community',{method:'POST',cookie:user.cookie,body:{kind:'service-review',rating:0,body:'这个窗口服务很好'}})).status,400);
  assert.equal((await f.call('/api/community',{method:'POST',cookie:user.cookie,body:{kind:'guide',title:'标题完整',body:'太长'.repeat(11000)}})).status,413);
  assert.deepEqual((await f.call('/api/auth',{cookie:user.cookie})).data,{signedIn:true,user:{username:'同学甲'}});
});
