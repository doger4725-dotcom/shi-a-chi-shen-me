import test from 'node:test';
import assert from 'node:assert/strict';
import { dailyPlan, foodClues } from '../public/nutrition.js';
import { DISHES } from '../public/model.js';

test('三餐来自当前菜单，各餐时段正确，合计不突破扣除预留后的预算', () => {
  for (let variant = 0; variant < 8; variant++) {
    const plan = dailyPlan({ dishes: DISHES, budget: 40, reserve: 6, variant });
    assert.equal(plan.ok, true);
    assert.deepEqual(plan.meals.map((meal) => meal.period), ['breakfast', 'lunch', 'dinner']);
    for (const meal of plan.meals) {
      const original = DISHES.find((dish) => dish.id === meal.id);
      assert.ok(original.periods.includes(meal.period));
      assert.equal(meal.price, original.price);
    }
    assert.equal(plan.total, plan.meals.reduce((sum, meal) => sum + meal.price, 0));
    assert.ok(plan.total + plan.reserve <= plan.budget);
    assert.equal(plan.remaining, 40 - plan.total);
    assert.equal('calories' in plan, false);
  }
});
test('低预算无法安排三餐时明确失败，不省略餐次', () => {
  const plan = dailyPlan({ dishes: DISHES, budget: 10, reserve: 0 });
  assert.equal(plan.ok, false); assert.equal(plan.minimum, 27); assert.match(plan.reason, /漏餐/);
  assert.equal(dailyPlan({ dishes: DISHES, budget: 27, reserve: 0 }).ok, true);
});
test('空菜单和缺少餐段不会混入演示菜品', () => {
  const plan = dailyPlan({ dishes: [], budget: 50 });
  assert.equal(plan.ok, false); assert.equal(plan.missingPeriods.length, 3);
  const lunchOnly = dailyPlan({ dishes: DISHES.filter((dish) => dish.periods.includes('lunch')), budget: 50 });
  assert.deepEqual(lunchOnly.missingPeriods, ['breakfast', 'dinner']);
});
test('尊重清淡、蛋奶素标记及避开关键词的限制', () => {
  const light = dailyPlan({ dishes: DISHES, budget: 60, preference: 'light' });
  assert.ok(light.ok); assert.ok(light.meals.every((meal) => meal.taste === '清淡'));
  const vegetarian = dailyPlan({ dishes: DISHES, budget: 60, preference: 'vegetarian' });
  assert.ok(vegetarian.ok); assert.ok(vegetarian.meals.every((meal) => meal.tags.some((tag) => ['素食', '蛋奶素'].includes(tag))));
  const avoid = dailyPlan({ dishes: DISHES, budget: 60, avoid: '番茄、鸡蛋, 牛肉' });
  assert.ok(avoid.ok); assert.ok(avoid.meals.every((meal) => !/番茄|鸡蛋|牛肉/.test(meal.name)));
});
test('金额校验及分为单位的预算边界', () => {
  for (const input of [{ budget: NaN }, { budget: 0 }, { budget: 301 }, { reserve: -1 }, { budget: 20, reserve: 20 }]) assert.equal(dailyPlan({ dishes: DISHES, ...input }).ok, false);
  const dishes = ['breakfast', 'lunch', 'dinner'].map((period, index) => ({ id: String(index), name: '米饭', price: 1.1, periods: [period] }));
  assert.equal(dailyPlan({ dishes, budget: 3.3, reserve: 0 }).total, 3.3);
  assert.equal(dailyPlan({ dishes, budget: 3.29, reserve: 0 }).ok, false);
});
test('分类仅返回菜名线索，不把土豆认作蔬菜或豆浆认作奶类', () => {
  assert.deepEqual(foodClues({ name: '土豆饭' }), ['staple']);
  assert.deepEqual(foodClues({ name: '豆浆' }), ['protein']);
  assert.deepEqual(foodClues({ name: '神秘套餐' }), []);
});
