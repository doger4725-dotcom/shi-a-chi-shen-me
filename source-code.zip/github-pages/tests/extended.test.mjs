import test from 'node:test';
import assert from 'node:assert/strict';
import {budgetHint,waitHint,estimateWait,getCandidates} from '../public/model.js';
import {menuDishFromInput,historySampleFromInput} from '../public/collection.js';
import {validatePost} from '../lib/community.mjs';

test('预算提示按严格边界与早午晚餐切换',()=>{
  for(const n of [81,100,101])assert.equal(budgetHint(n),'记得饕餮只是传说');
  for(const [period,label] of [['breakfast','早餐'],['lunch','午餐'],['dinner','晚餐']])assert.equal(budgetHint(3,period),`天下没有免费的${label}`);
  assert.equal(budgetHint(11),'巴适');assert.equal(budgetHint(19),'巴适');
  for(const n of [4,10,20,80])assert.equal(budgetHint(n),'只推荐不超过预算的菜品');
  assert.equal(waitHint(9),'速战速决');assert.equal(waitHint(31),'美味值得等待');
  for(const n of [10,30])assert.equal(waitHint(n),'按预计等待时间筛选');
});
const now=Date.parse('2026-10-18T04:10:00Z');
const history=[4,5,12].map((minutes,i)=>({canteenId:'canteen-3',windowName:'窗口A',queuedAt:now-[1,7,8][i]*86400000,minutes}));
test('历史样本只合并同窗口相近时刻，取中位数，人工填报仍优先',()=>{
  const base={canteenId:'canteen-3',windowName:'窗口A',time:'12:10',now,history};
  const wait=estimateWait(base);assert.equal(wait.source,'history');assert.equal(wait.minutes,5);assert.equal(wait.sampleCount,3);assert.equal(wait.low,4);assert.equal(wait.high,12);
  assert.equal(estimateWait({...base,windowName:'窗口B'}).source,'model');
  assert.equal(estimateWait({...base,history:history.slice(0,2)}).source,'model');
  assert.equal(estimateWait({...base,time:'13:00'}).source,'model');
  assert.equal(estimateWait({...base,history:history.map((s)=>({...s,queuedAt:now-31*86400000}))}).source,'model');
  const report={canteenId:'canteen-3',windowName:'窗口B',targetTime:'12:10',minutes:2,createdAt:now};
  assert.equal(estimateWait({...base,reports:[report]}).source,'history');
  assert.equal(estimateWait({...base,reports:[{...report,windowName:'窗口A'}]}).minutes,2);
});
test('菜品按所属窗口等待独立筛选',()=>{
  const dishes=['窗口A','窗口B'].map((windowName,i)=>({id:String(i),canteenId:'canteen-3',windowName,name:'菜品'+i,price:12,periods:['lunch'],taste:'清淡',tags:[]}));
  const results=getCandidates({dishes,history,now,budget:20,maxWait:6,time:'12:10'});
  assert.deepEqual(results.map((d)=>d.windowName),['窗口A']);
});
test('真实资料录入拒绝未确认、无效菜价、未来采样，保留有效记录',()=>{
  const dish={id:'real',name:' 青椒肉丝饭 ',windowName:'一号窗口',price:'12.5',periods:['lunch','dinner'],taste:'微辣',verified:true};
  assert.equal(menuDishFromInput(dish).name,'青椒肉丝饭');
  assert.throws(()=>menuDishFromInput({...dish,verified:false}));
  assert.throws(()=>menuDishFromInput({...dish,price:''}));
  assert.throws(()=>menuDishFromInput({...dish,periods:[]}));
  assert.throws(()=>historySampleFromInput({windowName:'一号窗口',queuedAt:now+1,minutes:3},now));
  assert.equal(historySampleFromInput({windowName:'一号窗口',queuedAt:now,minutes:0},now).minutes,0);
});
test('菜品和服务五星必选且最多五颗，APP报错与攻略无星级',()=>{
  const review={kind:'dish-review',rating:5,dishId:'dish-7',dishName:'番茄饭',mealKey:'meal-1',body:''};
  assert.equal(validatePost(review).rating,5);
  for(const rating of [0,6,3.5,NaN])assert.throws(()=>validatePost({...review,rating}));
  assert.throws(()=>validatePost({...review,mealKey:''}));
  assert.throws(()=>validatePost({kind:'service-review',body:'出餐速度很快',rating:0}));
  assert.equal(validatePost({kind:'app-issue',body:'点了转盘后没有响应',rating:99}).rating,null);
  assert.equal(validatePost({kind:'guide',title:'三食堂攻略',body:'这个窗口中午很方便'}).alias,'干饭同学');
  assert.throws(()=>validatePost({kind:'reply',body:'这个搭配我也推荐',parentId:''}));
  assert.throws(()=>validatePost({kind:'app-issue',body:'x'.repeat(1501)}));
});
