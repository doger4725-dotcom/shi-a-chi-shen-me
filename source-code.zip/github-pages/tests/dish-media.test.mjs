import test from 'node:test';
import assert from 'node:assert/strict';
import {dishPhoto,dishVisual} from '../public/dish-media.js';
test('实拍只对应09号黑鸭肉酱拌面及其账本记录',()=>{
  assert.equal(dishPhoto({id:'lh3-09-22'}),'black-duck-noodles-09.png');
  assert.equal(dishPhoto({dishId:'lh3-09-22'}),'black-duck-noodles-09.png');
  assert.equal(dishPhoto({id:'lh3-09-20'}),null);
  assert.equal(dishPhoto({id:'constructor'}),null);
  assert.equal(dishPhoto({id:'__proto__'}),null);
});
test('图标中的HTML被转义且外部图片地址不被采用',()=>{
  const output=dishVisual({id:'other',emoji:'<img src=x onerror=alert(1)>',photo:'https://example.com/x'});
  assert.ok(!output.includes('<img'));
  assert.ok(output.includes('&lt;img'));
  assert.ok(!output.includes('https://'));
});
