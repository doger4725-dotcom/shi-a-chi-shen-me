import test from 'node:test';
import assert from 'node:assert/strict';
import { decisionOptions, normalizeTiming, weightedPool, chooseWeighted, landingRotation, attachTiming, fitScore } from '../public/decision.js';
import { CAMPUS_MENU, CAMPUS_OBSERVATIONS, CAMPUS_EXTRAS } from '../public/canteen-data.js';
import { estimateWait, dayType } from '../public/model.js';
const now = Date.parse('2026-10-18T12:00:00+08:00');
const filters = {budget:18,maxWait:30,time:'11:30',period:'lunch',taste:'all',canteenId:'canteen-3',windowName:''};
function result(extra={}) {return decisionOptions({filters,timing:normalizeTiming(),dishes:CAMPUS_MENU,observations:CAMPUS_OBSERVATIONS,now,...extra});}
test('照片菜单的窗口与金额完整，加料不作为正餐，只有午餐供应已采集',()=>{
  assert.ok(CAMPUS_MENU.length>90);assert.equal(new Set(CAMPUS_MENU.map(d=>d.id)).size,CAMPUS_MENU.length);
  assert.equal(CAMPUS_MENU.find(d=>d.windowNumber==='01').price,5);
  assert.equal(CAMPUS_MENU.find(d=>d.name==='无情拌面').price,7.5);
  assert.ok(CAMPUS_MENU.every(d=>d.price>0&&d.verified&&d.taste==='口味待录入'&&d.periods.join()==='lunch'));
  assert.equal(CAMPUS_EXTRAS.find(d=>d.name==='辣条').price,1);
  assert.ok(!CAMPUS_MENU.some(d=>d.name==='辣条'));
});
test('09号单次实测只用于周末相近时刻，8分钟已含出餐',()=>{
  const wait=estimateWait({canteenId:'canteen-3',windowName:'09号·卫孔记面馆',time:'11:30',observations:CAMPUS_OBSERVATIONS,now});
  assert.equal(wait.source,'observation');assert.equal(wait.includesPickup,true);assert.equal(wait.minutes,8);
  const item=result().current.find(d=>d.windowNumber==='09');
  assert.equal(item.pickup,0);assert.equal(item.elapsed,4+8+12+4);assert.equal(item.returnAt,'11:54');
  assert.equal(estimateWait({canteenId:'canteen-3',windowName:item.windowName,time:'12:10',observations:CAMPUS_OBSERVATIONS,now}).source,'model');
  assert.equal(estimateWait({canteenId:'canteen-3',windowName:item.windowName,time:'11:30',observations:CAMPUS_OBSERVATIONS,now:now+86400000}).source,'model');
  assert.equal(dayType(now),'weekend');assert.equal(dayType(now+86400000),'weekday');
});
test('总时间限制改变候选，时间足够与不足都返回一致方案',()=>{
  const normal=result();assert.ok(normal.current.length);assert.ok(normal.plans.every(d=>d.elapsed<=45));
  assert.equal(normal.plans.find(p=>p.kind==='fast').windowNumber,'09');
  assert.equal(normal.plans.find(p=>p.kind==='cheap').windowNumber,'01');
  const narrow=result({timing:normalizeTiming({available:28})});assert.ok(narrow.current.every(d=>d.windowNumber==='09'));assert.ok(narrow.excluded.length);
  const none=result({timing:normalizeTiming({available:25})});assert.equal(none.current.length,0);assert.equal(none.plans.length,0);
  assert.equal(result({filters:{...filters,budget:4}}).current.length,0);
  assert.equal(result({filters:{...filters,period:'dinner',time:'18:00'}}).current.length,0);
});
test('概率、扇区和实际抽取共用同一权重，显示合计100%',()=>{
  const pool=weightedPool(result().current);
  assert.equal(pool.length,8);assert.equal(Math.round(pool.reduce((s,d)=>s+d.percent,0)*10),1000);
  assert.ok(new Set(pool.map(d=>d.percent)).size>1);assert.equal(pool[0].arcStart,0);assert.equal(pool.at(-1).arcEnd,1);
  for(const item of pool){const mid=(item.arcStart+item.arcEnd)/2;assert.equal(chooseWeighted(pool,()=>mid).id,item.id);assert.ok(Math.abs(((landingRotation(item)+mid*360)%360))<1e-8);}
  assert.equal(chooseWeighted([],()=>0),null);
  const counts=pool.map(()=>0);for(let i=0;i<10000;i++)counts[pool.indexOf(chooseWeighted(pool,()=>(i+.5)/10000))]++;
  pool.forEach((d,i)=>assert.ok(Math.abs(counts[i]-d.probability*10000)<2));
});
test('目标、口味与等待都会影响权重；未知口味保持中性',()=>{
  const timing=normalizeTiming({favorite:'微辣',objective:'taste'});
  const base={price:10,wait:{minutes:8},taste:'微辣'};
  const known=attachTiming(base,timing), unknown=attachTiming({...base,taste:'口味待录入'},timing), other=attachTiming({...base,taste:'清淡'},timing);
  const score=d=>fitScore(d,{budget:18,timing}).weight;
  assert.ok(score(known)>score(unknown)&&score(unknown)>score(other));
  assert.ok(score(known)>score(attachTiming({...base,wait:{minutes:18}},timing)));
  assert.equal(normalizeTiming(null).available,45);
});
