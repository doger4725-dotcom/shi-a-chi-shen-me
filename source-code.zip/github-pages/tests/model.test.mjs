import assert from 'node:assert/strict';
import test from 'node:test';
// data URL keeps this test independent of package.json's module type.
import { readFile } from 'node:fs/promises';
const source = await readFile(new URL('../public/model.js', import.meta.url), 'utf8');
const { CANTEENS, DISHES, estimateWait, getCandidates, monthlyBudget } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const now = Date.parse('2026-10-18T04:10:00Z'); // 上海 12:10。
const staffReport = (extra = {}) => ({ canteenId: 'canteen-3', minutes: 7, createdAt: now - 5 * 60_000, targetTime: '12:10', ...extra });

test('龙河校区第三食堂单点试用，三个餐段各六条未核实的演示菜品', () => {
  assert.equal(CANTEENS.length, 1);
  assert.equal(CANTEENS[0].id, 'canteen-3');
  assert.equal(CANTEENS[0].name, '第三食堂');
  assert.equal(CANTEENS[0].subtitle, '安徽大学 · 龙河校区');
  assert.equal(CANTEENS[0].dataStatus, 'demo');
  assert.equal(DISHES.length, 18);
  assert.equal(new Set(DISHES.map((dish) => dish.id)).size, DISHES.length);
  for (const dish of DISHES) {
    assert.ok(CANTEENS.some((canteen) => canteen.id === dish.canteenId));
    assert.ok(dish.price > 0);
    assert.ok(['清淡', '微辣', '香辣'].includes(dish.taste));
    assert.equal(dish.verified, false);
    assert.match(dish.windowName, /^演示窗口 [ABC]$/);
  }
  for (const period of ['breakfast', 'lunch', 'dinner']) assert.equal(DISHES.filter((dish) => dish.periods.includes(period)).length, 6);
  assert.ok(DISHES.filter((dish) => dish.periods.includes('breakfast')).every((dish) => dish.price <= 10));
});

test('午餐高峰比开餐时更拥挤，估计包含明确数据来源和范围', () => {
  const quiet = estimateWait({ canteenId: 'canteen-3', time: '10:35', now });
  const peak = estimateWait({ canteenId: 'canteen-3', time: '12:05', now });
  assert.ok(peak.minutes > quiet.minutes);
  assert.equal(peak.source, 'model');
  assert.equal(peak.updatedAt, null);
  assert.ok(peak.low <= peak.minutes && peak.high >= peak.minutes);
  assert.match(peak.detail, /尚未实测校准/);
});

test('新鲜且对应所选用餐时刻的人工报告优先，采用最新报告', () => {
  const report = staffReport();
  const result = estimateWait({ canteenId: 'canteen-3', time: '12:10', reports: [staffReport({ minutes: 18, createdAt: now - 20 * 60_000 }), report], now });
  assert.equal(result.source, 'staff');
  assert.equal(result.minutes, 7);
  assert.equal(result.updatedAt, report.createdAt);
  const zero = estimateWait({ canteenId: 'canteen-3', time: '12:10', reports: [staffReport({ minutes: 0 })], now });
  assert.equal(zero.minutes, 0);
  assert.equal(zero.low, 0);
});

test('超过 30 分钟、对应时刻超过 30 分钟、餐段不符、未来/无效报告均回退', () => {
  for (const extra of [
    { createdAt: now - 30 * 60_000 - 1 },
    { targetTime: '11:39' },
    { period: 'breakfast' },
    { createdAt: now + 1 },
    { minutes: -1 },
    { minutes: NaN },
    { canteenId: 'canteen-2' },
    { targetTime: '25:00' },
  ]) {
    assert.equal(estimateWait({ canteenId: 'canteen-3', time: '12:10', reports: [staffReport(extra)], now }).source, 'model', JSON.stringify(extra));
  }
  assert.equal(estimateWait({ canteenId: 'canteen-3', time: '12:10', reports: [staffReport({ createdAt: now - 30 * 60_000, targetTime: '11:40' })], now }).source, 'staff');
});

test('无对应时刻的报告使用上海填报时刻，不能套用至其他用餐时段', () => {
  const report = staffReport({ targetTime: undefined, createdAt: '2026-10-18T04:05:00Z' });
  assert.equal(estimateWait({ canteenId: 'canteen-3', time: '12:10', reports: [report], now }).source, 'staff');
  assert.equal(estimateWait({ canteenId: 'canteen-3', time: '13:00', reports: [report], now }).source, 'model');
});

test('营业边界、无效时间以及不营业时填报不能产生可选菜品', () => {
  for (const time of ['06:29', '09:30', '14:00', '16:29', '20:00', '25:00', '12:99']) {
    assert.equal(estimateWait({ canteenId: 'canteen-3', time, reports: [staffReport({ targetTime: time })], now }).closed, true, time);
  }
  assert.equal(estimateWait({ canteenId: 'canteen-3', time: '06:30', now }).closed, false);
  assert.deepEqual(getCandidates({ time: '14:00', now }), []);
  assert.deepEqual(getCandidates({ period: 'breakfast', time: '12:10', now }), []);
});

test('筛选同时满足预算、食堂、餐段、口味与等待上限；无解返回空数组', () => {
  const candidates = getCandidates({ budget: 12, canteenId: 'canteen-3', period: 'lunch', taste: '清淡', maxWait: 10, time: '12:10', reports: [staffReport()], now });
  assert.deepEqual(candidates.map((dish) => dish.id), ['dish-07', 'dish-10']);
  assert.equal(candidates[0].wait.minutes, 7);
  assert.deepEqual(getCandidates({ budget: 1, now }), []);
  assert.deepEqual(getCandidates({ maxWait: 0, now }), []);
  assert.deepEqual(getCandidates({ budget: NaN, now }), []);
  const sorted = getCandidates({ budget: 25, maxWait: 30, now });
  assert.ok(sorted.length > 0);
  assert.ok(sorted.every((dish, index) => index === 0 || sorted[index - 1].score >= dish.score));
  assert.ok(getCandidates({ taste: '素食', now }).every((dish) => dish.tags.includes('素食')));
});

test('自采菜单可替换演示菜单，仍严格应用餐段/预算/食堂/口味/等待筛选', () => {
  const dishes = [
    { id: 'real-1', name: '自采菜 A', canteenId: 'canteen-3', price: 9, periods: ['lunch'], taste: '清淡', verified: true, windowName: '采集窗口' },
    { id: 'real-2', name: '超预算菜', canteenId: 'canteen-3', price: 19, periods: ['lunch'], taste: '清淡' },
    { id: 'real-3', name: '晚餐菜', canteenId: 'canteen-3', price: 8, periods: ['dinner'], taste: '清淡' },
    { id: 'real-4', name: '其他食堂菜', canteenId: 'canteen-2', price: 8, periods: ['lunch'], taste: '清淡' },
    { id: 'real-5', name: '辣菜', canteenId: 'canteen-3', price: 8, periods: ['lunch'], taste: '香辣' },
    { id: 'bad', name: '无效价格', canteenId: 'canteen-3', price: '9', periods: ['lunch'], taste: '清淡' },
    null,
  ];
  const filters = { dishes, budget: 12, canteenId: 'canteen-3', period: 'lunch', taste: '清淡', time: '12:10', maxWait: 10, reports: [staffReport()], now };
  const candidates = getCandidates(filters);
  assert.deepEqual(candidates.map((dish) => dish.id), ['real-1']);
  assert.equal(candidates[0].verified, true);
  assert.equal(candidates[0].windowName, '采集窗口');
  assert.deepEqual(getCandidates({ ...filters, maxWait: 6 }), []);
  assert.deepEqual(getCandidates({ ...filters, dishes: [] }), []);
  assert.deepEqual(getCandidates({ ...filters, dishes: null }), []);
});

test('月餐费包含本月初始金额，只计入上海当月记录，天数含今天', () => {
  const result = monthlyBudget({ limit: 600, openingSpent: 200, date: new Date(now), entries: [
    { price: 12, date: '2026-10-18' },
    { price: 10, date: '2026-09-30T16:00:00Z' }, // 上海 10 月 1 日。
    { price: 99, date: '2026-10-31T16:00:00Z' }, // 上海 11 月 1 日。
    { price: 90, date: '2026-09-30T15:59:59Z' },
    { price: 1, date: 'invalid' },
  ] });
  assert.equal(result.spent, 222);
  assert.equal(result.remaining, 378);
  assert.equal(result.daysLeft, 14);
  assert.equal(result.dailyAllowance, 27);
  assert.equal(result.ratio, 222 / 600);
});

test('上海月底和闰年天数正确，超预算保留欠额但日均建议不为负', () => {
  const finalDay = monthlyBudget({ limit: 10, openingSpent: 13.1, entries: [{ price: 0.2, date: '2024-02-29' }], date: new Date('2024-02-29T15:59:00Z') });
  assert.deepEqual(finalDay, { spent: 13.3, remaining: -3.3, daysLeft: 1, dailyAllowance: 0, ratio: 1.33 });
  assert.equal(monthlyBudget({ date: new Date('2024-02-28T16:00:00Z') }).daysLeft, 1);
  assert.equal(monthlyBudget({ date: new Date('2026-10-18T16:00:00Z') }).daysLeft, 13);
  assert.deepEqual(monthlyBudget({ limit: 0, openingSpent: 0, date: new Date(now) }), { spent: 0, remaining: 0, daysLeft: 14, dailyAllowance: 0, ratio: 0 });
});
