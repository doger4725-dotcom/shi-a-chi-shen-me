import { createHash, randomBytes, randomUUID, scrypt as derive, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { AppError, readValue, takeQuota } from './data.mjs';

const scrypt = promisify(derive);
export const SESSION_AGE = 30 * 86400000;
export const digest = value => createHash('sha256').update(value).digest('hex');
const sessionKey = token => `session/${digest(token)}`;
const cookieName = request => new URL(request.url).protocol === 'https:' ? '__Host-csm-session' : 'csm-local-session';

export function sessionCookie(request, token, maxAge = SESSION_AGE / 1000) {
  const secure = new URL(request.url).protocol === 'https:' ? '; Secure' : '';
  return `${cookieName(request)}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure}`;
}

function cookieToken(request) {
  const name = cookieName(request);
  return (request.headers.get('cookie') || '').split(';').map(s => s.trim()).find(s => s.startsWith(`${name}=`))?.slice(name.length + 1) || '';
}

export async function currentUser(request, store, now = Date.now()) {
  const token = cookieToken(request);
  if (!/^[a-f0-9]{64}$/.test(token)) return null;
  const session = await readValue(store, sessionKey(token));
  if (!session || session.expiresAt <= now) return null;
  return { userId: session.userId, username: session.username };
}

function credentials(input) {
  const username = typeof input.username === 'string' ? input.username.normalize('NFKC').trim().toLowerCase() : '';
  const password = typeof input.password === 'string' ? input.password : '';
  if (!/^[\p{L}\p{N}_-]{2,24}$/u.test(username)) throw new AppError('用户名用2～24个字母、数字、汉字或下划线。');
  if (password.length < 8 || password.length > 128 || Buffer.byteLength(password) > 256) throw new AppError('密码请填写8～128个字符。');
  return { username, password };
}

export async function authenticate({ request, input, action, store, ip, now = Date.now() }) {
  if (!['login', 'signup'].includes(action)) throw new AppError('请选择登录或注册。');
  const { username, password } = credentials(input);
  const window = Math.floor(now / 900000);
  if (!await takeQuota(store, `auth-rate/${digest(ip)}:${window}`, 15, (window + 1) * 900000)) throw new AppError('登录尝试较多，请15分钟后再试。', 429);
  const key = `account/${digest(username)}`;
  let account = await readValue(store, key);
  if (action === 'signup') {
    const hour = Math.floor(now / 3600000);
    if (!await takeQuota(store, `signup-rate/${digest(ip)}:${hour}`, 5, (hour + 1) * 3600000)) throw new AppError('本时段注册较多，请稍后再试。', 429);
    if (account) throw new AppError('这个用户名已被使用。', 409);
    const salt = randomBytes(16).toString('hex');
    const passwordHash = Buffer.from(await scrypt(password, salt, 64)).toString('hex');
    account = { userId: randomUUID(), username, salt, passwordHash, createdAt: now };
    const result = await store.setJSON(key, account, { onlyIfNew: true });
    if (!result.modified) throw new AppError('这个用户名已被使用。', 409);
  } else {
    // 不存在的账号也执行一次同样的密码计算。
    const computed = Buffer.from(await scrypt(password, account?.salt || 'csm-missing-user-salt', 64));
    const expected = Buffer.from(account?.passwordHash || '00'.repeat(64), 'hex');
    if (!account || computed.length !== expected.length || !timingSafeEqual(computed, expected)) throw new AppError('用户名或密码不正确。', 401);
  }
  const token = randomBytes(32).toString('hex');
  await store.setJSON(sessionKey(token), { userId: account.userId, username: account.username, expiresAt: now + SESSION_AGE });
  return { user: { userId: account.userId, username: account.username }, cookie: sessionCookie(request, token) };
}

export async function signOut(request, store) {
  const token = cookieToken(request);
  if (/^[a-f0-9]{64}$/.test(token)) await store.delete(sessionKey(token));
  return sessionCookie(request, '', 0);
}
