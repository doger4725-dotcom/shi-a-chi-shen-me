import { AppError, takeQuota } from './data.mjs';
import { authenticate, currentUser, digest, signOut } from './auth.mjs';
import { readCommunity, writeCommunity, withdrawCommunity } from './community.mjs';
import { nutritionAIInput, nutritionMessages, askDeepSeek } from '../lib/nutrition-ai.mjs';
import { dailyPlan } from '../public/nutrition.js';

const headers = {'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const json = (data,status=200,extra={})=>Response.json(data,{status,headers:{...headers,...extra}});
const loginRequired = () => json({error:'登录后即可使用。',signInPath:'#login'},401);

async function bodyJSON(request,limit=20000) {
  if(request.headers.get('origin')!==new URL(request.url).origin) throw new AppError('请从本站页面提交。',403);
  if(!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) throw new AppError('提交格式应为JSON。',415);
  if(Number(request.headers.get('content-length'))>limit) throw new AppError('提交内容过长。',413);
  const reader=request.body?.getReader(); if(!reader) throw new AppError('请填写提交内容。');
  const parts=[];let bytes=0;
  for(;;){const {value,done}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>limit){await reader.cancel();throw new AppError('提交内容过长。',413);}parts.push(value);}
  const buffer=new Uint8Array(bytes);let offset=0;for(const part of parts){buffer.set(part,offset);offset+=part.byteLength;}
  let value;try{value=JSON.parse(new TextDecoder().decode(buffer));}catch{throw new AppError('提交格式无效，请刷新后重试。');}
  if(!value||typeof value!=='object'||Array.isArray(value))throw new AppError('提交格式无效，请刷新后重试。');
  return value;
}

export function createAPI({store,settings=()=>process.env,fetcher=fetch,clock=()=>Date.now()}) {
  return async function handle(request,{ip='local'}={}) {
    try{
      const url=new URL(request.url),method=request.method,path=url.pathname.replace(/\/$/,'');
      const now=clock(),user=await currentUser(request,store,now);
      if(path==='/api/auth'){
        if(method==='GET')return json({signedIn:Boolean(user),user:user?{username:user.username}:null});
        if(method!=='POST')return json({error:'不支持这种操作。'},405,{'Allow':'GET, POST'});
        const input=await bodyJSON(request,4096);
        if(input.action==='logout')return json({ok:true},200,{'Set-Cookie':await signOut(request,store)});
        const result=await authenticate({request,input,action:input.action,store,ip,now});
        return json({signedIn:true,user:{username:result.user.username}},input.action==='signup'?201:200,{'Set-Cookie':result.cookie});
      }
      if(path==='/api/community'){
        if(method==='GET')return json(await readCommunity(store,url.searchParams,user));
        if(!['POST','DELETE'].includes(method))return json({error:'不支持这种操作。'},405,{'Allow':'GET, POST, DELETE'});
        if(!user)return loginRequired();
        const input=await bodyJSON(request);
        if(method==='DELETE')return json(await withdrawCommunity({store,input,user,now}));
        return json({post:await writeCommunity({store,input,user,now,ip})},201);
      }
      if(path==='/api/nutrition'){
        if(!['GET','POST'].includes(method))return json({error:'不支持这种操作。'},405,{'Allow':'GET, POST'});
        if(!user)return loginRequired();
        const env=settings(),key=env.DEEPSEEK_API_KEY?.trim();
        if(method==='GET')return json({configured:Boolean(key),provider:'DeepSeek',verified:false,message:key?'DeepSeek已配置。':'DeepSeek待配置，三餐搭配可用。'});
        const input=nutritionAIInput(await bodyJSON(request,120000));
        if(!key)return json({error:'DeepSeek待配置，请先使用三餐搭配。'},503);
        const hour=Math.floor(now/3600000),day=new Date(now+28800000).toISOString().slice(0,10);
        const quotas=[
          [`ai-hour/${user.userId}:${hour}`,10,(hour+1)*3600000],
          [`ai-ip/${digest(ip)}:${hour}`,20,(hour+1)*3600000],
          [`ai-day/${user.userId}:${day}`,30,now+86400000],
          [`ai-site/${day}`,100,now+86400000],
        ];
        for(const [bucket,limit,expiresAt] of quotas)if(!await takeQuota(store,bucket,limit,expiresAt))return json({error:'本时段AI次数已用完，请稍后再试。'},429);
        const plan=dailyPlan({dishes:input.menu,budget:input.budget,reserve:input.reserve,preference:input.preference,avoid:input.avoid});
        try{
          const reply=await askDeepSeek({key,model:env.DEEPSEEK_MODEL?.trim()||'deepseek-flash',messages:nutritionMessages(input,plan),fetcher});
          return json({reply,provider:'DeepSeek',verified:true});
        }catch(error){return json({error:error instanceof Error&&error.message.startsWith('DeepSeek')?error.message:'AI回复超时，请稍后再试。'},502);}
      }
      return json({error:'没有这个接口。'},404);
    }catch(error){
      if(error instanceof AppError)return json({error:error.message,...(error.status===401?{signInPath:'#login'}:{})},error.status);
      // 只将明确的输入错误返回页面，存储与运行时错误保留统一提示。
      if(error instanceof Error&&/^(问题请|问题中|一次最多|菜单中|菜单缺少|请先填写有效)/.test(error.message))return json({error:error.message},400);
      return json({error:'服务暂时不可用，请稍后再试。'},503);
    }
  };
}
