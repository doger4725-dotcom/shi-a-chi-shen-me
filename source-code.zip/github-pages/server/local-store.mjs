import { DatabaseSync } from 'node:sqlite';

// 本机用SQLite保存；上线后，同一接口改由Netlify Blobs保存。
export function localStore(filename=':memory:') {
  const db=new DatabaseSync(filename);
  db.exec('PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS records (key TEXT PRIMARY KEY,data TEXT NOT NULL,revision INTEGER NOT NULL)');
  return {
    async getWithMetadata(key){const row=db.prepare('SELECT data,revision FROM records WHERE key=?').get(key);return row?{data:JSON.parse(row.data),etag:`"${row.revision}"`}:null;},
    async setJSON(key,value,options={}){
      const data=JSON.stringify(value);let info;
      if(options.onlyIfNew)info=db.prepare('INSERT OR IGNORE INTO records(key,data,revision) VALUES(?,?,1)').run(key,data);
      else if(options.onlyIfMatch){const revision=Number(options.onlyIfMatch.replaceAll('"',''));info=db.prepare('UPDATE records SET data=?,revision=revision+1 WHERE key=? AND revision=?').run(data,key,revision);}
      else info=db.prepare('INSERT INTO records(key,data,revision) VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET data=excluded.data,revision=records.revision+1').run(key,data);
      return {modified:info.changes>0};
    },
    async delete(key){db.prepare('DELETE FROM records WHERE key=?').run(key);},
    close(){db.close();},
  };
}
