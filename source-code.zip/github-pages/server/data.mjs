// 每次更新都带上读到的版本号；并发提交时重新读取，避免相互覆盖。
export class AppError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}

export async function readValue(store, key, fallback = null) {
  const entry = await store.getWithMetadata(key, { type: 'json', consistency: 'strong' });
  return entry ? entry.data : fallback;
}

export async function updateValue(store, key, initial, change) {
  for (let attempt = 0; attempt < 12; attempt++) {
    const entry = await store.getWithMetadata(key, { type: 'json', consistency: 'strong' });
    const value = entry ? entry.data : structuredClone(initial);
    const outcome = await change(value);
    if (outcome?.skip) return outcome.result;
    const saved = await store.setJSON(key, value, entry ? { onlyIfMatch: entry.etag } : { onlyIfNew: true });
    if (saved.modified) return outcome?.result;
  }
  throw new AppError('提交较多，请稍后再试。', 503);
}

export async function takeQuota(store, key, limit, expiresAt) {
  return updateValue(store, key, { count: 0, expiresAt }, value => {
    if (value.count >= limit) return { skip: true, result: false };
    value.count++;
    return { result: true };
  });
}

export function publicPost(row, userId) {
  const { authorId, mealKey, deleted, ...fields } = row;
  return { ...fields, mine: authorId === userId, ...(authorId === userId && mealKey ? { mealKey } : {}) };
}
