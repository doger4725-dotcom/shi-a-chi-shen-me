import { randomUUID } from 'node:crypto';
import { COMMUNITY_KINDS, validatePost } from '../lib/community.mjs';
import { AppError, publicPost, readValue, updateValue, takeQuota } from './data.mjs';
import { digest } from './auth.mjs';

const KEY = 'community/posts';
const order = (a,b) => b.createdAt - a.createdAt || b.id.localeCompare(a.id);

export async function readCommunity(store, query, user) {
  const rows = await readValue(store, KEY, []), visible = rows.filter(row => !row.deleted);
  if (query.get('view') === 'meta') {
    const sums = new Map();
    for (const row of visible.filter(p => p.kind === 'dish-review')) {
      const sum = sums.get(row.dishId) || { dishId: row.dishId, sum: 0, count: 0 };
      sum.sum += row.rating; sum.count++; sums.set(row.dishId, sum);
    }
    return { signedIn: Boolean(user), ratings: [...sums.values()].map(r=>({dishId:r.dishId,average:r.sum/r.count,count:r.count})),
      reviews: user ? visible.filter(p=>p.kind==='dish-review'&&p.authorId===user.userId).sort(order).slice(0,200).map(p=>publicPost(p,user.userId)) : [] };
  }
  const kind = query.get('kind') || 'guide';
  if (!COMMUNITY_KINDS.includes(kind)) throw new AppError('没有这个内容分类。');
  const parentId = query.get('parentId') || '';
  if (kind === 'reply' && !visible.some(p=>p.id===parentId&&p.kind==='guide')) throw new AppError('这篇攻略已撤回或不存在。',404);
  const offset = Math.floor(Math.max(0,Math.min(10000,Number(query.get('offset'))||0)));
  const dishId = query.get('dishId');
  const selected = visible.filter(p=>p.kind===kind&&(kind!=='reply'||p.parentId===parentId)&&(!dishId||p.dishId===dishId)).sort(order).slice(offset,offset+21);
  return { posts:selected.slice(0,20).map(p=>publicPost(p,user?.userId)), hasMore:selected.length>20 };
}

export async function writeCommunity({store,input,user,now=Date.now(),ip}) {
  if (!user) throw new AppError('登录后即可发布内容。',401);
  let post; try { post=validatePost(input); } catch(error) { throw new AppError(error.message); }
  const minute=Math.floor(now/60000);
  if (!await takeQuota(store,`post-rate/${user.userId}:${minute}`,10,(minute+1)*60000) || !await takeQuota(store,`post-ip/${digest(ip)}:${minute}`,30,(minute+1)*60000)) throw new AppError('发布较频繁，请一分钟后再试。',429);
  const id=randomUUID();
  return updateValue(store,KEY,[],rows=>{
    if (post.kind==='reply'&&!rows.some(p=>p.id===post.parentId&&p.kind==='guide'&&!p.deleted)) throw new AppError('这篇攻略已撤回或不存在。',404);
    const existing = post.kind==='dish-review' ? rows.find(p=>p.authorId===user.userId&&p.mealKey===post.mealKey) : null;
    if (existing) { Object.assign(existing,post,{deleted:0,updatedAt:now}); return {result:publicPost(existing,user.userId)}; }
    if (rows.length>=5000) throw new AppError('社区存储已满，请联系项目负责人归档。',503);
    const row={id,authorId:user.userId,...post,createdAt:now,updatedAt:now,deleted:0};
    rows.push(row); return {result:publicPost(row,user.userId)};
  });
}

export async function withdrawCommunity({store,input,user,now=Date.now()}) {
  if (!user) throw new AppError('登录后可以撤回自己的内容。',401);
  if(typeof input?.id!=='string'||input.id.length>100) throw new AppError('内容标识无效。');
  return updateValue(store,KEY,[],rows=>{
    const row=rows.find(p=>p.id===input.id&&p.authorId===user.userId&&!p.deleted);
    if(!row) throw new AppError('这条内容不属于你，或已撤回。',404);
    row.deleted=1;row.updatedAt=now;return {result:{ok:true}};
  });
}
